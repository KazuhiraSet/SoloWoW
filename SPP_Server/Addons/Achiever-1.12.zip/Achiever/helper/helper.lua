-- AchieverUtils = {}

-- AchieverUtils.split = function(str, sep)
--     if sep == nil then
--         sep = '%s'
--     end

--     local res = {}
--     local func = function(w)
--         table.insert(res, w)
--     end

--     string.gsub(str, '[^'..sep..']+', func)
--     return res
-- end





-- AchieverUtils.tablelength = function(T)
--     local count = 0
--     for _ in pairs(T) do count = count + 1 end
--     return count
-- end